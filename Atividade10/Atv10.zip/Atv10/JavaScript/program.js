//Primeira Maneira

var Aluno1 = {};

var ra_propriedade = 'ra';

var nome_propriedade = 'nome';

Aluno1[ra_propriedade] = '0030482111023';

Aluno1[nome_propriedade] = 'José Arruda da Silva';

//Segunda Maneira

var Aluno1 = new Object();

Aluno1.ra_propriedade = '0030482111023';

Aluno1.nome_propriedade = 'José Arruda da Silva';

//Terceira Maneira

var Aluno1 = {
    ra_propriedade : '0030482111023',
    nome_propriedade : 'José Arruda da Silva'
}