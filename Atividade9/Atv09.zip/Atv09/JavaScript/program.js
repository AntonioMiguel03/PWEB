var numeros = new Array();

var numA = prompt("Digite um número:");
numeros.push(numA);

var numB = prompt("Digite outro número:");
numeros.push(numB);

var numC = prompt("Digite outr número:");
numeros.push(numC);

document.write("Maior valor: " + Math.max.apply(null, numeros) + "<br><br><br>");


document.write("Ordem Crescente: "+ numeros.sort(function(a, b){return a - b}));




