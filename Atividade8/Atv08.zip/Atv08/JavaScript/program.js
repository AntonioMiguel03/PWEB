var qtdItems = 2;

var somaIdade = 0, qtdPessimo = 0, qtdBom = 0, qtdOtimo = 0, qtdHomem = 0, qtdMulher = 0;

var idades = Array(qtdItems);

var sexos = Array(qtdItems);

var opinioes = Array(qtdItems);

for(var i = 0; i < qtdItems; i++){
    idades[i] = parseInt(prompt("Informe uma idade: "));  
    
    somaIdade = somaIdade + idades[i];
    
    sexos[i] = prompt("Informe o sexo\nF - Feminino \nM - Masculino");

    sexos[i] == "F" ? qtdMulher = qtdMulher + 1 : 0;

    sexos[i] == "M" ? qtdHomem = qtdHomem + 1 : 0;

    opinioes[i] = parseInt(prompt("Informe a opinião: \n1 - Péssimo \n2 - Regular \n3 - Bom \n4 - Ótimo"));

    opinioes[i] == 1 ? qtdPessimo = qtdPessimo + 1 : 0;        

    opinioes[i] == 3 ? qtdBom = qtdBom + 1 : 0;   

    opinioes[i] == 4 ? qtdOtimo = qtdOtimo + 1 : 0;  
}



var media = somaIdade / qtdItems;

var maiorIdade = Math.max.apply(null, idades);

document.write("Média das idades: " + media);

document.write("<br><br>Idade da pessoa mais velha: " + maiorIdade);

document.write("<br><br>Quantidade de pessoas que responderam péssimo: " + qtdPessimo);

var pctBom = qtdBom / qtdItems * 100;

var pctOtimpo = qtdOtimo / qtdItems * 100;

document.write("<br><br>Porcentagem de pessoas que acharam o filme bom " + pctBom + "%");

document.write("<br><br>Porcentagem de pessoas que acharam o filme ótimo " + pctOtimpo + "%");

document.write("<br><br>Total de mulheres: " + qtdMulher);

document.write("<br><br>Total de homens: " + qtdHomem);